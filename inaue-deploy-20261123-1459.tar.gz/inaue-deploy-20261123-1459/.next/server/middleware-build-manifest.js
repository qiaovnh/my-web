globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/rm3a3ayQlFlZXT39I076e/_buildManifest.js",
    "static/rm3a3ayQlFlZXT39I076e/_ssgManifest.js",
    "static/rm3a3ayQlFlZXT39I076e/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1pcw6gskne7pf.js",
    "static/chunks/1qhkxvx29u7za.js",
    "static/chunks/092r-mewpaf3q.js",
    "static/chunks/0gy1dczh8t-w0.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/geo/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/login/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/orders/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/orders/[id]/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/pages/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/products/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/products/[handle]/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/products/new/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/settings/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(store)/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(store)/checkout/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(store)/checkout/success/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(store)/collections/[handle]/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(store)/products/[handle]/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(store)/search/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/1qhkxvx29u7za.js",
        "static/chunks/092r-mewpaf3q.js",
        "static/chunks/0gy1dczh8t-w0.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
