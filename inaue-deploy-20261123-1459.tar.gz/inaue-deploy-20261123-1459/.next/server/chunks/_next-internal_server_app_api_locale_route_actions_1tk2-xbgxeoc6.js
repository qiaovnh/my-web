module.exports=[93455,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_locale_route_actions_1tk2-xbgxeoc6.js.map