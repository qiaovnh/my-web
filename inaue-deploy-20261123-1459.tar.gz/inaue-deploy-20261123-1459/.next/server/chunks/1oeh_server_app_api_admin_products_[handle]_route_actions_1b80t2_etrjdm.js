module.exports=[29935,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_admin_products_%5Bhandle%5D_route_actions_1b80t2_etrjdm.js.map