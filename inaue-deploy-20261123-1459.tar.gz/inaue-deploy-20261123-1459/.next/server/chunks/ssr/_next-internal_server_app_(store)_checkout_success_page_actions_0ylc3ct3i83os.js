module.exports=[20388,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28store%29_checkout_success_page_actions_0ylc3ct3i83os.js.map