module.exports=[75531,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28store%29_products_%5Bhandle%5D_page_actions_0tatpue3ngj-d.js.map