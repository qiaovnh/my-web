module.exports=[90868,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_admin_orders_page_actions_1q-3hdfwy6zkd.js.map