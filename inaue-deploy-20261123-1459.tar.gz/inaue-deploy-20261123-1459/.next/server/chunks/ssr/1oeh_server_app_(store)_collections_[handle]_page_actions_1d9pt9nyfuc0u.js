module.exports=[47117,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28store%29_collections_%5Bhandle%5D_page_actions_1d9pt9nyfuc0u.js.map