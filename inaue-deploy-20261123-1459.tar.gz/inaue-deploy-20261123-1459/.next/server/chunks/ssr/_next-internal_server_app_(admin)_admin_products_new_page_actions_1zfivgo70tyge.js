module.exports=[43485,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_admin_products_new_page_actions_1zfivgo70tyge.js.map