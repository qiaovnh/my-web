module.exports=[38285,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_robots_txt_route_actions_15vc_89wprgh5.js.map