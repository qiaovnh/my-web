module.exports=[51940,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_geo_route_actions_1xy6t_faxudc2.js.map