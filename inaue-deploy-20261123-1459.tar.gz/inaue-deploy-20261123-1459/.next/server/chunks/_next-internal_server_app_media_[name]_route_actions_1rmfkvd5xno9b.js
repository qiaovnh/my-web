module.exports=[64160,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_media_%5Bname%5D_route_actions_1rmfkvd5xno9b.js.map