var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/locale/route.js")
R.c("server/chunks/[externals]__0rm7cpnm9jrf1._.js")
R.c("server/chunks/_1pctokrqm5-ls._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/node_modules_next_0g8xe7c6fvfgl._.js")
R.c("server/chunks/_next-internal_server_app_api_locale_route_actions_1tk2-xbgxeoc6.js")
R.m(43845)
module.exports=R.m(43845).exports
