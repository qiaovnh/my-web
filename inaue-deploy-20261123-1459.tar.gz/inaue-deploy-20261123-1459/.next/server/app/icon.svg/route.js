var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.svg/route.js")
R.c("server/chunks/[externals]__0rm7cpnm9jrf1._.js")
R.c("server/chunks/_0wemi40xtpagp._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/node_modules_next_0g8xe7c6fvfgl._.js")
R.c("server/chunks/_next-internal_server_app_icon_svg_route_actions_1r2h_ubdhjtcp.js")
R.m(71315)
module.exports=R.m(71315).exports
