var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/media/[name]/route.js")
R.c("server/chunks/_1rfibdd9em5tp._.js")
R.c("server/chunks/[root-of-the-server]__1cw-ehq6l3zw3._.js")
R.c("server/chunks/_0r4d78qvqd7ky._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_next-internal_server_app_media_[name]_route_actions_1rmfkvd5xno9b.js")
R.m(99063)
module.exports=R.m(99063).exports
