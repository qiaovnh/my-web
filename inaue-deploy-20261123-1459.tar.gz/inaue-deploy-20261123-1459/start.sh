#!/usr/bin/env bash
# 启动 INAUE。环境变量从同目录 .env.production 读取。
set -euo pipefail
cd "$(dirname "$0")"

set -a
. ./.env.production
set +a

export PORT="${PORT:-3210}"
# 注意：不要用 ${HOSTNAME:-0.0.0.0}。HOSTNAME 在 Linux/macOS 上默认就是机器名，
# 兜底永远不生效，会导致服务只监听主机名，用 IP 访问连不上。这里固定绑定 0.0.0.0。
export HOSTNAME="0.0.0.0"
export NODE_ENV=production

exec node server.js
